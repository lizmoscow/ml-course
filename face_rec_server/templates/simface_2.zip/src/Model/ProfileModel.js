var ProfileModel = Backbone.Model.extend({
    defaults: {
        "photo_id": "1913341313278041549_5",
        "post": 'test_url',
        "score": "8.746237e-05",
        "username": "victoria_yakhno"
   }
});